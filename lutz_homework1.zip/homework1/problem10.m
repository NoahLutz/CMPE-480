x= linspace(-pi,pi,1e3);

mag_y = abs(exp((-1j*x*pi)/2).*cos(x-3));
phase_y = angle(exp((-1j*x*pi)/2).*cos(x-3));

subplot(2,1,1);
plot(x, mag_y);
xlabel('\omega');
ylabel('Magnitude');
xticks([-pi -pi/2 0 pi/2 pi])
xticklabels({'-\pi', '-\pi/2', '0', '\pi/2', '\pi'});

subplot(2,1,2);
plot (x, phase_y);
xlabel('\omega');
ylabel('Phase');
xticks([-pi -pi/2 0 pi/2 pi])
xticklabels({'-\pi', '-\pi/2', '0', '\pi/2', '\pi'});
