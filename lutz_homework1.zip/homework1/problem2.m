v1 = 5:5:25;
v2 = 10:-1:6;

product = v1 * v2';
trueProduct = dot(v1,v2);