fplot(@(t) sin(3*(t-4))/(3*(t-4)), [0 8], '-x');
grid on
xlabel('t');
ylabel('y');