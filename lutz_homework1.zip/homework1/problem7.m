function [mag,theta] = problem7(z)
mag = abs(z);
theta = angle(z);